
$(function () {
    $('#myTab a').tab('show');
});
$(document).ready(function(){
    $('.spinnerExample').spinner({});
})
